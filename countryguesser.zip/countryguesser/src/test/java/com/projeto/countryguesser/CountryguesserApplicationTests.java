package com.projeto.countryguesser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountryguesserApplicationTests {

	@Test
	void contextLoads() {
	}

}
